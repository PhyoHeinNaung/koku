@props([
    'label',
    'description' => null,
])

<label {{ $attributes->class('flex cursor-pointer items-center justify-between gap-5 rounded-xl bg-base-200/55 px-4 py-3.5') }}>
    <span class="min-w-0">
        <strong class="block text-xs font-semibold">{{ $label }}</strong>
        @if ($description)
            <small class="mt-0.5 block text-[11px] text-base-content/45">{{ $description }}</small>
        @endif
    </span>

    {{ $slot }}
</label>

@props([
    'label',
    'name',
    'required' => false,
])

<fieldset {{ $attributes->class('fieldset gap-1.5') }}>
    <label for="{{ $name }}" class="text-xs font-semibold text-base-content/75">
        {{ $label }}
        @if ($required)
            <span class="text-error" aria-hidden="true">*</span>
        @endif
    </label>

    {{ $slot }}

    @error($name)
        <p class="text-xs text-error">{{ $message }}</p>
    @enderror
</fieldset>

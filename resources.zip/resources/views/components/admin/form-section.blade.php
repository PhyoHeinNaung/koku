@props([
    'title',
])

<section {{ $attributes->class('overflow-hidden rounded-2xl border border-base-300/70 bg-base-100 shadow-sm') }}>
    <header class="flex items-center gap-3 border-b border-base-300/60 px-5 py-4 sm:px-6">
        @isset($icon)
            <span class="grid size-9 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
                {{ $icon }}
            </span>
        @endisset

        <h2 class="text-sm font-semibold">{{ $title }}</h2>

        @isset($actions)
            <div class="ml-auto">
                {{ $actions }}
            </div>
        @endisset
    </header>

    <div class="p-5 sm:p-6">
        {{ $slot }}
    </div>
</section>

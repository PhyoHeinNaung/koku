<div class="mx-auto w-full max-w-6xl" x-data="{ tab: 'identity' }">
    <form wire:submit="save" class="space-y-5">
        <x-admin.page-header title="Store settings" />

        <div class="overflow-hidden rounded-2xl border border-base-300/70 bg-base-100 shadow-sm">
            <div class="flex items-center gap-1 overflow-hidden border-b border-base-300/60 px-3 pt-3 sm:px-5"
                role="tablist" aria-label="Store setting sections">
                @foreach ([
                    ['id' => 'identity', 'label' => 'Store profile', 'icon' => 'M5 20V7l7-4 7 4v13M9 20v-5h6v5M8 9h.01M12 9h.01M16 9h.01'],
                    ['id' => 'checkout', 'label' => 'Checkout policies', 'icon' => 'M4 6h16v12H4V6Zm0 4h16M8 15h3'],
                ] as $item)
                    <button type="button" role="tab" @click="tab = '{{ $item['id'] }}'"
                        :aria-selected="(tab === '{{ $item['id'] }}').toString()"
                        class="relative flex h-10 shrink-0 items-center gap-2 rounded-t-lg px-3 text-[11px] font-medium transition-colors"
                        :class="tab === '{{ $item['id'] }}'
                            ? 'bg-base-200/70 text-base-content after:absolute after:inset-x-3 after:-bottom-px after:h-0.5 after:rounded-full after:bg-accent'
                            : 'text-base-content/45 hover:bg-base-200/40 hover:text-base-content'">
                        <svg class="size-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                            stroke-width="1.7" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="{{ $item['icon'] }}" />
                        </svg>
                        {{ $item['label'] }}
                    </button>
                @endforeach
            </div>

            <div x-show="tab === 'identity'" role="tabpanel" class="p-5 sm:p-7">
                <div class="grid gap-8 lg:grid-cols-[minmax(0,1fr)_16rem]">
                    <div class="space-y-7">
                        <section>
                            <div class="mb-4 flex items-center gap-3">
                                <span class="grid size-9 place-items-center rounded-xl bg-accent/12 text-accent">
                                    <svg class="size-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                        stroke-width="1.7" aria-hidden="true">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M5 20V7l7-4 7 4v13M9 20v-5h6v5M8 9h.01M12 9h.01M16 9h.01" />
                                    </svg>
                                </span>
                                <div>
                                    <h2 class="text-sm font-semibold">Store identity</h2>
                                    <p class="mt-0.5 text-[10px] text-base-content/40">Public and legal business names.</p>
                                </div>
                            </div>

                            <div class="grid gap-4 sm:grid-cols-2">
                                <x-admin.form-field label="Store name" name="storeName" required>
                                    <input id="storeName" type="text" wire:model="storeName"
                                        class="input input-bordered h-10 w-full rounded-lg text-xs"
                                        autocomplete="organization">
                                </x-admin.form-field>

                                <x-admin.form-field label="Legal name" name="legalName">
                                    <input id="legalName" type="text" wire:model="legalName"
                                        class="input input-bordered h-10 w-full rounded-lg text-xs"
                                        autocomplete="organization">
                                </x-admin.form-field>
                            </div>
                        </section>

                        <div class="h-px bg-base-300/60"></div>

                        <section>
                            <div class="mb-4">
                                <h2 class="text-sm font-semibold">Customer support</h2>
                            </div>

                            <div class="grid gap-4 sm:grid-cols-2">
                                <x-admin.form-field label="Support email" name="supportEmail">
                                    <input id="supportEmail" type="email" wire:model="supportEmail"
                                        class="input input-bordered h-10 w-full rounded-lg text-xs"
                                        autocomplete="email">
                                </x-admin.form-field>

                                <x-admin.form-field label="Support phone" name="supportPhone">
                                    <input id="supportPhone" type="tel" wire:model="supportPhone"
                                        class="input input-bordered h-10 w-full rounded-lg text-xs"
                                        autocomplete="tel">
                                </x-admin.form-field>

                                <x-admin.form-field label="Business address" name="businessAddress"
                                    class="sm:col-span-2">
                                    <textarea id="businessAddress" wire:model="businessAddress" rows="3"
                                        class="textarea textarea-bordered w-full resize-y rounded-lg text-xs"
                                        autocomplete="street-address"></textarea>
                                </x-admin.form-field>

                                <x-admin.form-field label="Default country" name="defaultCountry" required>
                                    <input id="defaultCountry" type="text" wire:model="defaultCountry"
                                        class="input input-bordered h-10 w-full rounded-lg text-xs"
                                        autocomplete="country-name">
                                </x-admin.form-field>
                            </div>
                        </section>
                    </div>

                    <aside class="h-fit rounded-xl bg-base-200/55 p-4">
                        <p class="text-[8px] font-semibold uppercase tracking-[0.16em] text-base-content/35">Store preview</p>
                        <div class="mt-4 flex items-center gap-3">
                            <span class="grid size-10 shrink-0 place-items-center rounded-xl bg-neutral text-sm font-bold text-neutral-content">
                                T
                            </span>
                            <span class="min-w-0">
                                <strong class="block truncate text-sm" x-text="$wire.storeName || 'TICKS'"></strong>
                                <small class="mt-0.5 block truncate text-[10px] text-base-content/40"
                                    x-text="$wire.supportEmail || 'No support email'"></small>
                            </span>
                        </div>
                        <dl class="mt-5 space-y-3 border-t border-base-300/70 pt-4 text-[10px]">
                            <div class="flex justify-between gap-4">
                                <dt class="text-base-content/40">Country</dt>
                                <dd class="truncate font-medium" x-text="$wire.defaultCountry || '—'"></dd>
                            </div>
                            <div class="flex justify-between gap-4">
                                <dt class="text-base-content/40">Currency</dt>
                                <dd class="font-medium">USD</dd>
                            </div>
                        </dl>
                    </aside>
                </div>
            </div>

            <div x-cloak x-show="tab === 'checkout'" role="tabpanel" class="p-5 sm:p-7">
                <div class="grid gap-8 lg:grid-cols-[minmax(0,1fr)_16rem]">
                    <div class="space-y-7">
                        <section>
                            <div class="mb-4 flex items-center gap-3">
                                <span class="grid size-9 place-items-center rounded-xl bg-accent/12 text-accent">
                                    <svg class="size-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                        stroke-width="1.7" aria-hidden="true">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M4 6h16v12H4V6Zm0 4h16M8 15h3" />
                                    </svg>
                                </span>
                                <div>
                                    <h2 class="text-sm font-semibold">Checkout access</h2>
                                    <p class="mt-0.5 text-[10px] text-base-content/40">Control who can place an order.</p>
                                </div>
                            </div>

                            <x-admin.switch-row label="Guest checkout"
                                description="Allow customers to purchase without signing in.">
                                <input type="checkbox" wire:model="guestCheckoutEnabled"
                                    class="toggle toggle-sm toggle-accent"
                                    aria-label="Enable guest checkout">
                            </x-admin.switch-row>
                        </section>

                        <div class="h-px bg-base-300/60"></div>

                        <section>
                            <div class="mb-4">
                                <h2 class="text-sm font-semibold">Order controls</h2>
                            </div>

                            <div class="grid gap-4 sm:grid-cols-2">
                                <x-admin.form-field label="Order prefix" name="orderPrefix" required>
                                    <label class="input input-bordered flex h-10 items-center gap-2 rounded-lg">
                                        <span class="text-[10px] text-base-content/35">#</span>
                                        <input id="orderPrefix" type="text" wire:model="orderPrefix"
                                            class="min-w-0 grow border-0 bg-transparent p-0 text-xs uppercase outline-none"
                                            maxlength="8">
                                    </label>
                                </x-admin.form-field>

                                <x-admin.form-field label="Low-stock threshold" name="lowStockThreshold" required>
                                    <input id="lowStockThreshold" type="number" wire:model="lowStockThreshold"
                                        min="1" max="9999"
                                        class="input input-bordered h-10 w-full rounded-lg text-xs">
                                </x-admin.form-field>
                            </div>
                        </section>

                        <div class="h-px bg-base-300/60"></div>

                        <section>
                            <div class="mb-4">
                                <h2 class="text-sm font-semibold">Delivery insurance</h2>
                            </div>

                            <div class="space-y-4">
                                <x-admin.switch-row label="Offer delivery insurance"
                                    description="Let customers add shipment protection at checkout.">
                                    <input type="checkbox" wire:model.live="insuranceEnabled"
                                        class="toggle toggle-sm toggle-accent"
                                        aria-label="Enable delivery insurance">
                                </x-admin.switch-row>

                                <x-admin.form-field label="Insurance rate" name="insuranceRate"
                                    x-show="$wire.insuranceEnabled" x-transition>
                                    <label class="input input-bordered flex h-10 max-w-52 items-center gap-2 rounded-lg">
                                        <input id="insuranceRate" type="number" wire:model="insuranceRate"
                                            min="0.1" max="25" step="0.1"
                                            class="min-w-0 grow border-0 bg-transparent p-0 text-xs outline-none">
                                        <span class="text-xs text-base-content/40">%</span>
                                    </label>
                                </x-admin.form-field>
                            </div>
                        </section>
                    </div>

                    <aside class="h-fit rounded-xl border border-base-300/60 p-4">
                        <p class="text-[8px] font-semibold uppercase tracking-[0.16em] text-base-content/35">Commerce setup</p>
                        <dl class="mt-4 space-y-3 text-[10px]">
                            <div class="flex items-center justify-between gap-3">
                                <dt class="text-base-content/45">Payment</dt>
                                <dd><x-admin.badge tone="green">Stripe</x-admin.badge></dd>
                            </div>
                            <div class="flex items-center justify-between gap-3">
                                <dt class="text-base-content/45">Currency</dt>
                                <dd class="font-semibold">USD</dd>
                            </div>
                            <div class="flex items-center justify-between gap-3">
                                <dt class="text-base-content/45">Shipping rates</dt>
                                <dd>
                                    <a href="{{ route('admin.shipping.index') }}"
                                        class="font-medium text-accent underline-offset-2 hover:underline">Manage</a>
                                </dd>
                            </div>
                        </dl>
                        <p class="mt-4 border-t border-base-300/60 pt-4 text-[9px] leading-4 text-base-content/40">
                            Currency follows the current Stripe integration and cannot be changed here.
                        </p>
                    </aside>
                </div>
            </div>
        </div>

        <div class="sticky bottom-3 z-20 flex items-center justify-between gap-4 rounded-xl border border-base-300/80 bg-base-100/95 px-4 py-3 shadow-lg shadow-black/5 backdrop-blur">
            <span class="text-[10px] text-base-content/40">
                <span wire:dirty class="inline-flex items-center gap-2 text-warning">
                    <span class="size-1.5 rounded-full bg-warning"></span>
                    Unsaved changes
                </span>
                <span wire:dirty.remove>Settings are up to date</span>
            </span>

            <div class="flex items-center gap-2">
                <button type="button" wire:click="discardChanges" wire:dirty
                    class="btn btn-ghost btn-sm h-9 min-h-9 rounded-lg px-3 text-xs">
                    Discard
                </button>
                <button type="submit"
                    class="btn btn-primary btn-sm h-9 min-h-9 min-w-28 rounded-lg px-4 text-xs font-semibold"
                    wire:loading.attr="disabled" wire:target="save">
                    <span wire:loading.remove wire:target="save">Save settings</span>
                    <span wire:loading wire:target="save" class="loading loading-spinner loading-xs"></span>
                </button>
            </div>
        </div>
    </form>
</div>
